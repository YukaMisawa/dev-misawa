const config = {
  apiUrl: 'http://localhost:4783'
};

export default config;