const config = {
     apiUrl: '/api_yuka_misawa'
};

export default config;

